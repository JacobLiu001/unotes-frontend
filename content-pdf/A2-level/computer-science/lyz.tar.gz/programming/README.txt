The code here is probably bug-free.

The code in ./code_bank/ is code I wrote during the semester.
 - They have a higher probability of being correct
 - They have many for features and functions
 - They are written in my own code style, which is more OOP (Not CAIE's)
