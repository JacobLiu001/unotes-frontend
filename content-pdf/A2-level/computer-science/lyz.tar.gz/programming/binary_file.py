import pickle

filename = "test.dat"
address = 0

# read binary
file_handler = open(filename, "rb")

# Go to specified address
file_handler.seek(address)

# read some_object from file_handler at address previously specified.
some_object = pickle.load(file_handler)

file_handler.close()

# write binary
file_handler = open(filename, "wb")

# Go to specified address
file_handler.seek(address)

# write some_object to file_handler at address previously specified.
pickle.dump(some_object, file_handler)

file_handler.close()
