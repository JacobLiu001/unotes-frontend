#! /usr/bin/env python3
# Author: Yunzhi (Jacob) Liu
# Date: 2022-04-30

class Node:
    def __init__(self, data = "", left = -1, right = -1):
        self.data = data
        self.left = left
        self.right = right
    def __str__(self) -> str:
        return "(l=%s,r=%s,x=%s)"%(str(self.left), str(self.right), repr(self.data))
    def __repr__(self) -> str:
        return "(l=%s,r=%s,x=%s)"%(str(self.left), str(self.right), repr(self.data))

MAXLEN = 100

free_list = [Node("", i+1, -1) for i in range(MAXLEN-1)] + [Node()]
free_head = 0

root = -1

def malloc() -> int:
    global free_head, free_list
    if free_head == -1:
        raise MemoryError("Free list has run out!")
    new_node_address = free_head
    free_head = free_list[free_head].left
    free_list[new_node_address].left = -1
    return new_node_address

def insert(data):
    global root, free_head, free_list

    new_node_address = malloc()
    free_list[new_node_address].data = data

    if root == -1:
        root = new_node_address
        return

    prev, cur = -1, root
    while cur != -1:
        prev = cur
        if data < free_list[cur].data:
            cur = free_list[cur].left
        else:
            cur = free_list[cur].right

    if data < free_list[prev].data:
        free_list[prev].left = new_node_address
    else:
        free_list[prev].right = new_node_address

    return


# to_string and to_string_helper are just for debugging,
# you probably don't need it
def to_string_helper(root: int, pref = "") -> str:
    hasLeft = (free_list[root].left != -1)
    hasRight = (free_list[root].right != -1)
    if (not hasRight) and (not hasLeft):
        return ""
    ret = pref+("├──%s\n"%(str(free_list[free_list[root].left].data))  if hasLeft  else "├──(NULL)\n")
    ret+= to_string_helper(free_list[root].left,  pref+"│  ")      if hasLeft  else ""
    ret+= pref+("└──%s\n"%(str(free_list[free_list[root].right].data)) if hasRight else "└──(NULL)\n")
    ret+= to_string_helper(free_list[root].right, pref+"   ")      if hasRight else ""
    return ret

def to_string() -> str:
    if root == None:
        return "Empty Tree"
    ret0 = str(free_list[root].data) + "\n"
    return (ret0+to_string_helper(root))[:-1]


def debug():
    print(f"{root=}")
    for i, n in enumerate(free_list[:10]):
        print(i, n)
    print(to_string())

TEST = True

def test():
    # note that strings are sorted in lexicographical order.
    insert("5")
    insert("3")
    insert("22")
    insert("45")
    insert("95")
    debug()

if __name__ == "__main__":
    if TEST:
        test()
