#! /usr/bin/env python3
# Author: Yunzhi (Jacob) Liu
# Date: 2022-04-30

MAXSIZE = 100

lst = ["" for _ in range(MAXSIZE)]
head = 0 # points to the first element
tail = -1 # points to the last element
counter = 0

def push(data):
    global tail, counter
    if counter == MAXSIZE:
        print("Queue full. Discarding")
        return
    counter += 1
    tail = (tail + 1) % MAXSIZE
    lst[tail] = data

def pop():
    global head, counter
    if counter == 0:
        print("Queue empty. Ignoring")
        return
    counter -= 1
    element = lst[head]
    head = (head+1) % MAXSIZE
    return element

def peek():
    if counter == 0:
        print("Queue empty. Returning None")
        return None
    return lst[head]
