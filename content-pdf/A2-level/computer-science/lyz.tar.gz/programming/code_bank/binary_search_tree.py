class Node:
    def __init__(self, left = None, right = None, data = None):
        self.left:int = left
        self.right:int = right
        self.data:int = data
    def __str__(self) -> str:
        return "(l=%s,r=%s,x=%s)"%(str(self.left), str(self.right), repr(self.data))
    def __repr__(self) -> str:
        return "(l=%s,r=%s,x=%s)"%(str(self.left), str(self.right), repr(self.data))


def init_freelist(MAXN: int = 1000):
    global nodeList
    global freeHead
    freeHead = 0
    nodeList = [Node(i+1, None, None) for i in range(MAXN - 1)]
    nodeList.append(Node())

def allocate():
    global nodeList
    global freeHead
    if freeHead == None:
        raise MemoryError("Freelist has run out!")
    tmp = freeHead
    freeHead = nodeList[tmp].left
    nodeList[tmp].left = None
    nodeList[tmp].data = None  #
    nodeList[tmp].right = None # better be safe than sorry
    return tmp

def release(ptr):
    global nodeList
    global freeHead
    nodeList[ptr].data = None
    nodeList[ptr].right = None
    nodeList[ptr].left = freeHead
    freeHead = ptr


init_freelist()
# print(nodeList)

class BST:
    def __init__(self, root = None):
        self.root = root

    def insert(self, data):
        newNode = allocate()
        nodeList[newNode].data = data

        if self.root == None:
            self.root = newNode
            return

        cur = self.root
        prev = cur
        while cur != None:
            prev = cur
            if data <= nodeList[cur].data:
                cur = nodeList[cur].left
            else:
                cur = nodeList[cur].right
        if data <= nodeList[prev].data:
            nodeList[prev].left = newNode
        else:
            nodeList[prev].right = newNode

    def find(self, data) -> bool:
        cur = self.root
        while cur != None:
            if data == nodeList[cur].data:
                return True
            if data < nodeList[cur].data:
                cur = nodeList[cur].left
            else:
                cur = nodeList[cur].right
        return False

    def __preOrderTraversalHelper(self, root) -> list:
        ret0 = []
        if root != None:
            ret0.append(nodeList[root].data)
            ret0 += self.__preOrderTraversalHelper(nodeList[root].left)
            ret0 += self.__preOrderTraversalHelper(nodeList[root].right)
        return ret0

    def __inOrderTraversalHelper(self, root) -> list:
        ret0 = []
        if root != None:
            ret0 += self.__inOrderTraversalHelper(nodeList[root].left)
            ret0.append(nodeList[root].data)
            ret0 += self.__inOrderTraversalHelper(nodeList[root].right)
        return ret0

    def __postOrderTraversalHelper(self, root) -> list:
        ret0 = []
        if root != None:
            ret0 += self.__postOrderTraversalHelper(nodeList[root].left)
            ret0 += self.__postOrderTraversalHelper(nodeList[root].right)
            ret0.append(nodeList[root].data)
        return ret0

    def preOrderTraversal(self) -> list:
        return self.__preOrderTraversalHelper(self.root)

    def inOrderTraversal(self) -> list:
        return self.__inOrderTraversalHelper(self.root)

    def postOrderTraversal(self) -> list:
        return self.__postOrderTraversalHelper(self.root)

    def __stringHelper(self, root: int, pref = "") -> str:
        hasLeft = (nodeList[root].left != None)
        hasRight = (nodeList[root].right != None)
        if (not hasRight) and (not hasLeft):
            return ""
        ret = pref+("├──%s\n"%(str(nodeList[nodeList[root].left].data))  if hasLeft  else "├──(NULL)\n")
        ret+= self.__stringHelper(nodeList[root].left,  pref+"│  ")      if hasLeft  else ""
        ret+= pref+("└──%s\n"%(str(nodeList[nodeList[root].right].data)) if hasRight else "└──(NULL)\n")
        ret+= self.__stringHelper(nodeList[root].right, pref+"   ")      if hasRight else ""
        return ret
        # raise Exception("I fucked up.")

    def __str__(self) -> str:
        if self.root == None:
            return "Empty Tree"
        ret0 = str(nodeList[self.root].data) + "\n"
        return (ret0+self.__stringHelper(self.root))[:-1]

    def __bfsHelper(self, root: int):
        _q = list()
        ret = list()
        _q.append(root)
        while len(_q) != 0:
            cur = _q.pop(0)
            ret.append(nodeList[cur].data)
            if nodeList[cur].left != None:
                _q.append(nodeList[cur].left)
            if nodeList[cur].right != None:
                _q.append(nodeList[cur].right)
        return ret

    def bfs(self):
        return self.__bfsHelper(self.root)

    def __dfsHelper(self, root: int):
        _q = list()
        ret = list()
        _q.append(root)
        while len(_q) != 0:
            cur = _q.pop()
            ret.append(nodeList[cur].data)
            if nodeList[cur].right != None:
                _q.append(nodeList[cur].right)
            if nodeList[cur].left != None:
                _q.append(nodeList[cur].left)
        return ret

    def dfs(self):
        return self.__dfsHelper(self.root)



testTree = BST()
testTree.insert(5)
testTree.insert(10)
testTree.insert(2)
testTree.insert(4)
testTree.insert(6)
testTree.insert(12)
print(testTree.preOrderTraversal())
print(testTree.inOrderTraversal())
print(testTree.postOrderTraversal())
print(testTree.find(2))
print(testTree.dfs())
print(testTree)


