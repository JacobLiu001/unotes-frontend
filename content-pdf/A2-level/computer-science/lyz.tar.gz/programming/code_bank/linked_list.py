class Node:
    def __init__(self, ptr = None, data = None):
        self.ptr = ptr
        self.data = data

MAXSIZE = 100
def initFreeList():
    global nodeList
    global freeHead
    nodeList = [Node(i+1) for i in range(MAXSIZE)]
    nodeList[-1].ptr = None
    freeHead = 0

def allocate():
    global freeHead
    if freeHead == None:
        raise MemoryError("Free list has run out!")
    tmp = freeHead
    freeHead = nodeList[tmp].ptr
    nodeList[tmp].ptr = None
    return tmp

def release(ptr):
    global freeHead
    tmp = freeHead
    freeHead = ptr
    nodeList[ptr].ptr = tmp

class LList:
    # global nodeList
    def __init__(self, head: int = None):
        self.head:int = head
    def insertAtHead(self, data):
        newNodePtr = allocate()
        nodeList[newNodePtr].ptr = self.head
        nodeList[newNodePtr].data = data
        self.head = newNodePtr
    def __iter__(self):
        cur = self.head
        while cur != None:
            yield (nodeList[cur].data, nodeList[cur].ptr)
            cur = nodeList[cur].ptr

    def __len__(self):
        cnt = 0
        for _ in self:
            cnt = cnt + 1
        return cnt

    def __str__(self):
        cur:int = self.head
        res = ""
        res += "%s-(%s)"%(str(nodeList[cur].data), str(nodeList[cur].ptr))
        while True:
            cur = nodeList[cur].ptr
            if cur == None:
                break
            res += "->%s-(%s)"%(str(nodeList[cur].data), str(nodeList[cur].ptr))
        return res
    def __len__(self):
        cnt = 0
        cur = self.head
        while cur != None:
            cur = nodeList[cur].ptr
            cnt += 1
        return cnt
    def insertAtTail(self, data):
        if self.head is None:
            return self.insertAtHead(data)
        tail = self.head
        while tail != None:
            prev = tail
            tail = nodeList[tail].ptr
        new = allocate()
        nodeList[new].data = data
        nodeList[prev].ptr = new
        nodeList[new].ptr = None

    def removeAtHead(self):
        if self.head == None:
            raise ValueError("Linked List Underflow")
        tmp = self.head
        tmpData = nodeList[tmp].data
        self.head = nodeList[self.head].ptr
        release(tmp)
        return tmpData

    def removeAtTail(self):
        if self.head == None:
            raise ValueError("Linked List Underflow")
        if nodeList[self.head].ptr == None:
            return self.removeAtHead()
        tail = self.head
        while nodeList[tail].ptr != None:
            prev = tail
            tail = nodeList[tail].ptr
        data = nodeList[tail].data
        release(tail)
        nodeList[prev].ptr = None
        return data

    def search(self, data):
        for i, _ in self:
            if data == i:
                return True
        return False

    def delete(self, data):
        cur:int = self.head
        if self.head == None:
            raise ValueError("Linked List Underflow")
        if nodeList[self.head].data == data:
            self.removeAtHead()
            return
        if nodeList[self.head].ptr == None:
            raise ValueError("Object Not Found")
        while nodeList[cur].ptr != None:
            prev = cur
            cur = nodeList[cur].ptr
            if nodeList[cur].data == data:
                break
        else:
            raise ValueError("Object Not Found")
        nodeList[prev].ptr = nodeList[cur].ptr
        release(cur)


def main():
    initFreeList()
    a = LList()
    for i in range(10):
        a.insertAtHead(i)
    a.delete(5)
    print(a)

if __name__ == "__main__":
    main()

