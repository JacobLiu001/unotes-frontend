#! /usr/bin/env python3
# Author: Yunzhi (Jacob) Liu
# Date: 2022-04-29

class Node:
    def __init__(self, data, ptr) -> None:
        self.data = data
        self.ptr = ptr
    # I can't be bothered to do OOP things
    # If the paper asks you (explicitly) to use OOP,
    # put double underscore in the attribute names
    # and provide getters and setters

# CAIE Style linked list using global variables

MAX_SIZE = 100

linked_list = [Node("", i+1) for i in range(MAX_SIZE-1)] + [Node("", -1)]
free_head = 0

head = -1 # head of an application chain

def insert_at_head(data):
    global free_head
    global head
    global linked_list # Actually not needed, but better be safe than sorry.

    if free_head == -1: # if free list is empty
        # replace with your own
        print("Free list has run out!")
        return

    # remove node from free list
    new_node_address = free_head
    free_head = linked_list[free_head].ptr

    # put the data in the new node, and connect the new node to the list
    linked_list[new_node_address].data = data
    linked_list[new_node_address].ptr = head

    # head of the application chain should now be the new node
    head = new_node_address

    return

def insert_at_tail(data):
    global free_head
    global head
    global linked_list # Actually not needed, but better be safe than sorry.

    if free_head == -1: # if free list is empty
        # replace with your own
        print("Free list has run out!")
        return

    if head == -1: # list is empty
        insert_at_head(data)
        return

    # remove node from free list
    new_node_address = free_head
    free_head = linked_list[free_head].ptr
    linked_list[new_node_address].ptr = -1

    # put the data in the new node
    linked_list[new_node_address].data = data

    # find the last element in the list
    prev, cur = -1, head
    while cur != -1:
        prev = cur
        cur = linked_list[cur].ptr

    # prev cannot be -1
    linked_list[prev].ptr = new_node_address

    return

def delete_at_head():
    global free_head
    global head
    global linked_list # Actually not needed, but better be safe than sorry.

    if head == -1: # if list is empty
        # replace with your own error-handling code
        print("Tried to delete from an empty list! Ignoring")
        return

    # remove the node from the application list
    deleted_node_address = head
    linked_list[deleted_node_address].data = ""
    head = linked_list[head].ptr

    # return the node to free list
    linked_list[deleted_node_address].ptr = free_head
    free_head = deleted_node_address

    return

def delete_at_tail():
    global free_head
    global head
    global linked_list # Actually not needed, but better be safe than sorry.

    if head == -1: # if list is empty
        # replace with your own error-handling code
        print("Tried to delete from an empty list! Ignoring")
        return

    prev2, prev, cur = -1, -1, head
    while cur != -1:
        prev2 = prev
        prev = cur
        cur = linked_list[cur].ptr

    # cur is -1, prev is the last item, prev2 is the second-to-last item
    # prev is not -1, but prev2 may be
    if prev2 == -1:
        # only one item in list
        delete_at_head()
        return

    # remove node from application list
    deleted_node_address = prev
    linked_list[prev2].ptr = -1
    linked_list[deleted_node_address].data = ""

    # return the node to free list
    linked_list[deleted_node_address].ptr = free_head
    free_head = deleted_node_address


def find_element(data):
    cur = head
    while cur != -1:
        if linked_list[cur].data == data:
            return True
        cur = linked_list[cur].ptr
    return False


def insert_into_ordered(data):
    """This procedure inserts data into an ordered linked list
    at the earliest position
    such that the linked list is still ordered after insertion.
    """

    global free_head
    global head
    global linked_list # Actually not needed, but better be safe than sorry.

    if head == -1:
        insert_at_head(data)
        return

    prev, cur = -1, head

    while cur != -1 and data > linked_list[cur].data:
        prev = cur
        cur = linked_list[cur].ptr

    if prev == -1:
        # The appropriate spot is the first one
        insert_at_head(data)

    if cur == -1:
        # The approprite spot is the last one
        # OR because we already have `prev`,
        # we can copy that part of insert_at_tail here
        # but i'm lazy
        insert_at_tail(data)

    # insert into somewhere in the middle, after prev, before cur

    # take node from free list
    if free_head == -1:
        print("Free list has run out!")
        return

    new_node_address = free_head
    free_head = linked_list[free_head].ptr
    linked_list[new_node_address].data = data

    # put node between prev and cur
    linked_list[prev].ptr = new_node_address
    linked_list[new_node_address].ptr = cur

    return


def delete_element(data):
    """Finds the element with `data` and removes it from the linked list.
    """
    global free_head
    global head
    global linked_list # Actually not needed, but better be safe than sorry.

    prev, cur = -1, head

    while cur != -1 and linked_list[cur].data != data:
        prev = cur
        cur = linked_list[cur].ptr

    if cur == -1:
        print("Item cannot be found")
        return

    deleted_node_address = cur
    next_node = linked_list[deleted_node_address].ptr

    if prev == -1:
        delete_at_head()
        return

    linked_list[prev].ptr = next_node

    linked_list[deleted_node_address].data = ""
    linked_list[deleted_node_address].ptr = free_head
    free_head = deleted_node_address


def debug(cur: int = head):
    # This is sometimes more helpful than printing out the array
    while cur != -1:
        print("%s --> "%(str(linked_list[cur].data)), end="")
        cur = linked_list[cur].ptr
    print("(NULL)")

def verbose_debug(x):
    # this prints out the array
    # you probably don't want to understand \
    # how this specific piece of code works.
    # you definitely don't ever need to write this code
    print(f"Head: {head}")
    print("\n".join(
        map(lambda p: "%d, %s, %d"%(p[0], repr(p[1].data), p[1].ptr),
            enumerate(linked_list[0:x]))
    ))
    print("===========")

TEST = True

def test():
    debug(head)
    insert_at_tail(1) # 1
    insert_at_tail(2) # 1 2
    insert_at_tail(3) # 1 2 3
    insert_at_tail(4) # 1 2 3 4
    insert_at_head(-5) # -5 1 2 3 4
    insert_into_ordered(-2) # -5 -2 1 2 3 4
    insert_at_tail(10) # -5 -2 1 2 3 4 10
    delete_element(-5) # -2 1 2 3 4 10
    delete_at_head() # 1 2 3 4 10
    delete_element(2) # 1 3 4 10
    delete_at_tail()
    debug(head)

if __name__ == "__main__":
    if TEST:
        test()
