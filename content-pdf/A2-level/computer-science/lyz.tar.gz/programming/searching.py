#! /usr/bin/env python3
# Author: Yunzhi (Jacob) Liu
# Date: 2022-04-29

def linear_search(some_list, item) -> int:
    """Performs a linear search for item in some_list.
    Returns the index of the first appearance of item.

    Time complexity: O(n)
    """
    for i in range(len(some_list)):
        if some_list[i] == item:
            return i
    return -1

def binary_search_iterative(some_list, item) -> int:
    """Performs a binary search for item in some_list.
    Returns the index of the first appearance of item.

    Time complexity: O(log(n))
    """
    left = 0
    right = len(some_list) - 1
    while left <= right:
        mid = (left + right) // 2
        if item == some_list[mid]:
            return mid
        if item <  some_list[mid]:
            right = mid - 1
        else:
            left = mid + 1
    return -1

def binary_search_recursive(some_list, item, left, right) -> int:
    """Performs a binary search for item in some_list.
    Returns the index of the first appearance of item.

    Time complexity: O(log(n))
    """
    if left > right:
        return -1
    mid = (left + right) // 2
    if item == some_list[mid]:
        return mid
    if item <  some_list[mid]:
        return binary_search_recursive(some_list, item, left, mid-1)
    # item > some_list[mid]
    return binary_search_recursive(some_list, item, mid+1, right)
