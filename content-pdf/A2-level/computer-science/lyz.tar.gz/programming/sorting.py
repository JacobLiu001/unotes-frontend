#! /usr/bin/env python3
# Sorting algorithms (bubble and insertion)
# Author: Yunzhi (Jacob) Liu
# Date: 2022-04-29

def bubble_sort_naive(some_list):
    n = len(some_list)
    for _ in range(n-1):
        # n-1 passes over the array
        # here the variable name is not used later, so it can be replaced
        # with an underscore
        for j in range(n-1):
            if some_list[j] > some_list[j+1]:
                tmp = some_list[j]
                some_list[j] = some_list[j+1]
                some_list[j+1] = tmp
    # lists in Python are mutable, so no need to return the list.
    # For non-returning methods (i.e., procedures),
    # I still like to explicitly end it with an empty return.
    return
    # return some_list


def bubble_sort_optimization_1(some_list):
    n = len(some_list)
    for i in range(n-1):
        # the last `i` elements are already sorted, no need to look again
        for j in range(n-1-i):
            if some_list[j] > some_list[j+1]:
                tmp = some_list[j]
                some_list[j] = some_list[j+1]
                some_list[j+1] = tmp
    return


def bubble_sort_best(some_list):
    length_of_unsorted = len(some_list)
    isSorted = False
    while not isSorted:
        isSorted = True
        for j in range(length_of_unsorted-1):
            if some_list[j] > some_list[j+1]:
                isSorted = False
                tmp = some_list[j]
                some_list[j] = some_list[j+1]
                some_list[j+1] = tmp
        # you can also use i and count upwards
        # be extra careful about boundary conditions
        # and avoid off-by-1 errors
        length_of_unsorted -= 1
        # If no exchanges occur within one pass, the array is sorted. exit
    return

def insertion_sort(some_list):
    n = len(some_list)
    for i in range(1, n):
        item = some_list[i]
        j = i - 1
        while j >= 0 and some_list[j] > item:
            some_list[j+1] = some_list[j]
            j -= 1
        some_list[j+1] = item
    return


TEST = True

if TEST:
    from random import shuffle, randint


def test():
    for _ in range(100):
        len = 2**randint(4, 8) # 16-256
        arr = list(range(len))
        shuffle(arr)
        a1 = arr.copy()
        a2 = a1.copy()
        a3 = a2.copy()
        a4 = a3.copy()
        a5 = a4.copy()

        bubble_sort_naive(a1)
        bubble_sort_optimization_1(a2)
        bubble_sort_best(a3)
        insertion_sort(a4)
        a5.sort()

        assert(a1 == a2 == a3 == a4 == a5) # Throws error if false.

    print("Test success")

if __name__ == "__main__":
    if TEST:
        test()
