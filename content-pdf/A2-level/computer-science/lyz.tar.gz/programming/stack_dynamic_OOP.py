#! /usr/bin/env python3
# Author: Yunzhi (Jacob) Liu
# Date: 2022-04-30


class Stack:
    def __init__(self) -> None:
        self.__arr = list()

    def push(self, data):
        self.__arr.append(data)

    def pop(self):
        if len(self.__arr) == 0:
            print("Stack empty")
            return
        return self.__arr.pop()

    def peek(self):
        if len(self.__arr) == 0:
            print("Stack empty")
            return
        return self.__arr[-1]

    def _debug(self):
        print(self.__arr)

TEST = True

def test():
    myStack = Stack()
    myStack._debug()
    myStack.push(1)
    myStack.push(2)
    myStack.push(3)
    print(myStack.peek())
    print(myStack.pop())
    myStack._debug()

if __name__ == "__main__":
    if TEST:
        test()
