#! /usr/bin/env python3
# Author: Yunzhi (Jacob) Liu
# Date: 2022-04-30

MAXSIZE = 100

lst = ["" for _ in range(MAXSIZE)]
top = -1 # Points to the top element in stack.
# Beware of off-by-one errors
# if the paper asks for the pointer to point to the first empty space.

def push(data):
    global lst, top
    if top == MAXSIZE - 1:
        print("Stack full. Discarding.")
        return
    top += 1
    lst[top] = data

def pop():
    global lst, top
    if top == -1:
        print("Stack empty. Returning None.")
        return None  # Actually an empty return also returns None.
    element = lst[top]
    top -= 1
    return element

def peek():
    if top == -1:
        print("Stack empty. Returning None.")
        return None  # Actually an empty return also returns None.
    return lst[top]

def debug():
    print(lst[:top+1])

TEST = True

def test():
    debug()
    push(1)
    push(2)
    push(3)
    print(peek())
    print(pop())
    debug()

if __name__ == "__main__":
    if TEST:
        test()
