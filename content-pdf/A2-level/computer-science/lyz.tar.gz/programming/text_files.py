filename = "hello.txt"

some_string = "abcd"

# For read
file_handler = open(filename, "r")
# Read one line, string ends with a `\n`
# EOF returns empty string
file_handler.readline()
# Read all lines,
# returns a list of strings, each string ends with a '\n',
# you can run xxx.rstrip() to get rid of these characters at the end
file_handler.readlines()

file_handler.close()

# For write. If file does not exist it is created
# If file does exist, the contents are wiped.
file_handler = open(filename, "w")

# For write. If file exists it throws an error
# file_handler = open(filename, "x")
# Read+Write: "r+"
# Write+Read: "w+" (If file already exists, the file is wiped, not so useful)

# Write ONE STRING to the file. You need to manually include newlines
# Also, you cannot do write(str1, str2) like you do with print
file_handler.write(some_string)

# Write a list of strings to the file. DOES NOT include newlines
file_handler.writelines([some_string, some_string])

file_handler.close()
